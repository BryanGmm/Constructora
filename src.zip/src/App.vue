<template>
  <router-view /> <!-- Esto permite que el enrutador controle el layout -->
</template>

<script>
export default {
  name: 'App',
};
</script>

<style>
/* Estilos de App.vue, si tienes alguno */
</style>
